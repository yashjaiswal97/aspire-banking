import React from 'react';
import '../styles/CardSection.css';
import aspireLogo from '../assets/aspire-logo.png';
import aspireLogoWhite from '../assets/aspire-logo-white.png';
import eyeIcon from '../assets/eye-icon.png';
import freezeIcon from '../assets/freeze-icon.png';
import spendLimitIcon from '../assets/spend-limit-icon.png';
import gpayIcon from '../assets/gpay-icon.png';
import replaceIcon from '../assets/replace-card-icon.png';
import cancelIcon from '../assets/cancel-card-icon.png';
import refundIcon from '../assets/icons/transaction/refund.png';
import travelIcon from '../assets/icons/transaction/travel.png';
import adsIcon from '../assets/icons/transaction/ads.png';
import storeIcon from '../assets/icons/transaction/store.png';
import addCardBtn from '../assets/add.png';
import visaLogo from '../assets/visa-logo.png';

const CardSection = () => {
  return (
    <div className="card-container">
      <div className="top-section">
        <p className="label">Available balance</p>
        <div className='top-section-inner'>
        <p className="amount"><div className="currency">S$</div> 3,000</p>
        <button className="add-card-btn"><img src={addCardBtn} alt="Add Card Button" className="add-card-btn-icon" /> New card</button>
        </div>
      </div>

      <div className="tabs">
        <span className="active-tab">My debit cards</span>
        <span className="inactive-tab">All company cards</span>
      </div>

      <div className="card-info-box">
        <div className="card-left">
            <div className="show-card">
              <img src={eyeIcon} alt="Show Icon" />
              <span>Show card number</span>
            </div>
          <div className="green-card">
            <img src={aspireLogoWhite} alt="Aspire Logo" className="aspire-card-logo" />
            <p className="card-name">Mark Henry</p>
            <div className="card-number">•••• •••• •••• 2020</div>
            <div className="card-details">
              <span>Thru: 12/20</span>
              <span>CVV: ***</span>
            </div>
            <img src={visaLogo} alt="Aspire Logo" className="visa-logo" />
            
          </div>

          <div className="card-actions">
            <div className="action">
              <img src={freezeIcon} alt="" />
              <p>Freeze <br></br>card</p>
            </div>
            <div className="action">
              <img src={spendLimitIcon} alt="" />
              <p>Set spend <br></br> limit</p>
            </div>
            <div className="action">
              <img src={gpayIcon} alt="" />
              <p>Add to <br /> GPay</p>
            </div>
            <div className="action">
              <img src={replaceIcon} alt="" />
              <p>Replace <br />card</p>
            </div>
            <div className="action">
              <img src={cancelIcon} alt="" />
              <p>Cancel <br />card</p>
            </div>
          </div>
        </div>

        <div className="card-right">
          <div className="card-details-box">
            <h4>Card details</h4>
          </div>

          <div className="transactions-box">
            <h4>Recent transactions</h4>

            <div className="transaction">
              <img src={refundIcon} alt="Refund" />
              <div>
                <p className="merchant">Hamleys <span className="amount refund">+ S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Refund on debit card</p>
              </div>
            </div>
            <div className="transaction">
              <img src={refundIcon} alt="Refund" />
              <div>
                <p className="merchant">Hamleys <span className="amount refund">+ S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Refund on debit card</p>
              </div>
            </div>
            <div className="transaction">
              <img src={refundIcon} alt="Refund" />
              <div>
                <p className="merchant">Hamleys <span className="amount refund">+ S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Refund on debit card</p>
              </div>
            </div>
            <div className="transaction">
              <img src={refundIcon} alt="Refund" />
              <div>
                <p className="merchant">Hamleys <span className="amount refund">+ S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Refund on debit card</p>
              </div>
            </div>

            <div className="transaction">
              <img src={travelIcon} alt="Travel" />
              <div>
                <p className="merchant">Hamleys <span className="amount debit">- S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Charged to debit card</p>
              </div>
            </div>

            <div className="transaction">
              <img src={adsIcon} alt="Ads" />
              <div>
                <p className="merchant">Hamleys <span className="amount debit">- S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Charged to debit card</p>
              </div>
            </div>

            <div className="transaction">
              <img src={storeIcon} alt="Store" />
              <div>
                <p className="merchant">Hamleys <span className="amount debit">- S$ 150</span></p>
                <p className="date">20 May 2020</p>
                <p className="method">Charged to debit card</p>
              </div>
            </div>

            <div className="view-all">
              View all card transactions
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardSection;