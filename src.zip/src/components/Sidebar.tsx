import React from 'react';
import '../styles/Sidebar.css';
import logo from '../assets/aspire-logo.png';
import homeIcon from '../assets/icons/icon-home.png';
import cardsIcon from '../assets/icons/icon-cards.png';
import paymentsIcon from '../assets/icons/icon-payments.png';
import creditIcon from '../assets/icons/icon-credit.png';
import settingsIcon from '../assets/icons/icon-settings.png';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <img src={logo} alt="Aspire Logo" className="logo" />
      <p className="tagline">
          Trusted way of banking for 3,000+ SMEs and startups in Singapore
        </p>
      <nav className="menu">
        <div className="menu-item">
          <img src={homeIcon} alt="Home" />
          <span>Home</span>
        </div>
        <div className="menu-item">
          <img src={homeIcon} alt="Cards" />
          <span>Cards</span>
        </div>
        <div className="menu-item">
          <img src={homeIcon} alt="Payments" />
          <span>Payments</span>
        </div>
        <div className="menu-item">
          <img src={homeIcon} alt="Credit" />
          <span>Credit</span>
        </div>
        <div className="menu-item">
          <img src={homeIcon} alt="Settings" />
          <span>Settings</span>
        </div>
      </nav>

      
    </div>
  );
};

export default Sidebar;